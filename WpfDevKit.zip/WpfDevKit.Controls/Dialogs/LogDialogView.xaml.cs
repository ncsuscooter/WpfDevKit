using System.Windows.Controls;

namespace WpfDevKit.Controls.Dialogs
{
    /// <summary>
    /// Interaction logic for LogDialog.xaml
    /// </summary>
    public partial class LogDialogView : UserControl
    {
        public LogDialogView()
        {
            InitializeComponent();
        }
    }
}
