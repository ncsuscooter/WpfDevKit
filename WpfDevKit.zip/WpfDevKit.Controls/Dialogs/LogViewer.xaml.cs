using System.Windows.Controls;

namespace WpfDevKit.Controls.Dialogs
{
    /// <summary>
    /// Interaction logic for LogViewer.xaml
    /// </summary>
    public partial class LogViewer : UserControl
    {
        public LogViewer()
        {
            InitializeComponent();
        }
    }
}
