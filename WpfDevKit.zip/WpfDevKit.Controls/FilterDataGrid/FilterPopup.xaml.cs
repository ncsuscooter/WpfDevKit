using System.Windows.Controls;

namespace WpfDevKit.Controls.FilterDataGrid
{
    /// <summary>
    /// Interaction logic for FilterPopup.xaml
    /// </summary>
    public partial class FilterPopup : UserControl
    {
        public FilterPopup()
        {
            InitializeComponent();
        }
    }
}
