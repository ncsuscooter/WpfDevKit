﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using WpfDevKit.Controls.Dialogs.Interfaces;
using WpfDevKit.Interfaces;
using WpfDevKit.Logging.Extensions;
using WpfDevKit.Logging.Interfaces;

namespace WpfDevKit.Mvvm
{
    /// <summary>
    /// Provides a base class for pages that support commands and handle selected item changes.
    /// Inherits from <see cref="CommandBase"/> and implements <see cref="IDisposable"/>.
    /// </summary>
    public abstract class PageBase : CommandBase, IDisposable
    {
        protected readonly ILogService logService;
        protected readonly IBusyService busyService;
        protected readonly IDialogService dialogService;

        private IObservable selectedItem;
        private bool isDisposed;

        /// <summary>
        /// The message to indicate that the base method should be overridden to prevent execution.
        /// </summary>
        protected const string OVERRIDE_MESSAGE = "Override the base method to prevent execution";

        /// <summary>
        /// Gets or sets the currently selected item.
        /// </summary>
        public IObservable SelectedItem
        {
            get => selectedItem;
            set => SetValue(ref selectedItem, value);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PageBase"/> class.
        /// </summary>
        protected PageBase(IBusyService busyService, ICommandFactory commandFactory, IDialogService dialogService, ILogService logService) : base(commandFactory)
        {
            (this.busyService, this.dialogService, this.logService) = (busyService, dialogService, logService);
            logService.LogDebug(type: GetType());
            busyService.IsBusyChanged += OnBusyServiceIsBusyChanged;
        }

        /// <summary>
        /// Raises the <see cref="PropertyChanging"/> event for the specified property.
        /// </summary>
        /// <param name="propertyName">The name of the property that is changing.</param>
        public override void OnPropertyChanging([CallerMemberName] string propertyName = null)
        {
            try
            {
                #region SelectedItem
                if (propertyName.Equals(nameof(SelectedItem)))
                {
                    logService.LogDebug(null, $"{nameof(propertyName)}='{propertyName}'", GetType());
                    if (SelectedItem is IDisposable disposable)
                        disposable.Dispose();
                    if (SelectedItem != null)
                        SelectedItem.PropertyChanged -= OnSelectedItemPropertyChanged;
                }
                #endregion
            }
            catch (Exception ex)
            {
                dialogService.ShowDialog(ex, GetType());
            }
            base.OnPropertyChanging(propertyName);
        }

        /// <summary>
        /// Raises the <see cref="PropertyChanged"/> event for the specified property.
        /// </summary>
        /// <param name="propertyName">The name of the property that has changed.</param>
        public override void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            try
            {
                #region SelectedItem
                if (propertyName.Equals(nameof(SelectedItem)))
                {
                    logService.LogDebug(null, $"{nameof(propertyName)}='{propertyName}'", GetType());
                    if (SelectedItem != null)
                        SelectedItem.PropertyChanged += OnSelectedItemPropertyChanged;
                }
                #endregion
            }
            catch (Exception ex)
            {
                dialogService.ShowDialog(ex, GetType());
            }
            base.OnPropertyChanged(propertyName);
        }

        /// <summary>
        /// Disposes the page and cleans up any resources.
        /// </summary>
        public virtual void Dispose()
        {
            if (isDisposed)
                return;

            logService.LogDebug(type: GetType());
            try
            {
                SelectedItem = null;
            }
            finally
            {
                isDisposed = true;
                busyService.IsBusyChanged -= OnBusyServiceIsBusyChanged;
            }
        }

        private void OnBusyServiceIsBusyChanged() => OnPropertyChanged($"{nameof(busyService)}.{nameof(busyService.IsBusy)}");

        private void OnSelectedItemPropertyChanged(object sender, PropertyChangedEventArgs e) => OnPropertyChanged($"{nameof(SelectedItem)}.{e.PropertyName}");
    }
}
